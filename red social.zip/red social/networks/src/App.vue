<template>
  <nav>
  
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link> |
      <router-link to="/login">Login</router-link> |
      <router-link to="/registro">Registro</router-link> |

  </nav>
  <router-view/>
</template>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
width: 100%;
height: 80px;
padding: 30px;
background: rgb(238,174,202);
background: radial-gradient(circle, rgba(238,174,202,1) 0%, rgba(169,187,208,1) 100%);
  a {
    font-weight: bold;
    color: #024441;
    

    &.router-link-exact-active {
      color: #15a7ac;
      text-align: center;
    }
  }
}
.titulo{
font-size: 40px;
}
.form {
  text-align: right;
  font-family: 'Rubik Vinyl', cursive;
}
</style>
