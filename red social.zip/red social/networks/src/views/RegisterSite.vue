<template>
<div>
    <v-form v-model="valid" ref="formRegister">
      <v-row justify="center">
        <v-col cols="12">
          <v-text-field
            v-model="user.email"
            label="Email"
            :rules="emailRules"
            required
            class="bg-white"
          >
          </v-text-field>
          <v-text-field
            v-model="user.password"
            label="Password"
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            :rules="passwordRules"
            :type="show1 ? 'text' : 'password'"
            required
            counter
            maxlength="20"
            @click:append="show1 = !show1"
          >
          </v-text-field>
          <v-text-field
            v-model="user.repassword"
            label="Repita la contraseña"
            :rules="repasswordRules"
            required
          >
          </v-text-field>

          <v-btn
            block
            class="mx-auto mb-2"
            color="success"
            :disabled="!valid"
            @click="registerUser"
            >Registrar</v-btn
          >
          <v-btn block class="mx-auto mb-2" color="error" @click="reset"
            >Limpiar Formulario</v-btn
          >
          <v-btn block class="mx-auto" color="warning" @click="reset"
            >Limpiar Validación</v-btn
          >
        </v-col>
      </v-row>
    </v-form>
</div>
    <h1> Nuevo Componente</h1>
</template>

<script>
export default {
    name: 'component-name',
    // props: {},
    data: function(){
        return {
            valid: false,
      user: {
        email: "",
        password: "",
        repassword: "",
      },
      show1: false,
      emailRules: [
        (v) => (v && !!v.trim()) || "Escribe algo, no solo espacios.",
        (v) => !!v || "Por favor, escriba correo electrónico.",
        (v) =>
          /^[^@]+@[^@]+\.[a-zA-Z]{2,}$/.test(v) || "Formato incorrecto.",
      ],
      passwordRules: [
        (v) => (v && !!v.trim()) || "Escribe algo, no solo espacios.",
        (v) => !!v || "Por favor, escriba la contraseña.",
        (v) => (v && v.length > 5) || "Se requieren más de 6 caracteres.",
        (v) => (v && v.length < 12) || "Se requieren menos de 12 caracteres.",
      ],
      repasswordRules: [
        (v) => !!v || "No existe",
        (v) => v === this.user.repassword || "No coinciden las contraseñas",
      ],
    
        }
    },
    // computed: {},
    methods: {
        async registerUser() {
      try {
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          this.user.email,
          this.user.password
        );
        this.$router.push("/login");
      } catch (error) {
        switch (error.code) {
          case "auth/email-already-in-use":
            alert("El correo ya está siendo utilizado");
            break;
        }
      }
    }
},
    // components: {},
}
</script>

<style scoped>
    
</style>