<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloNetworks msg="Somos diferente!!!"/>
  </div>

  <Carrusel carrusel="Publica lo que quieras"/>
</template>

<script>
// @ is an alias to /src
import  HelloNetworks from '@/components/HelloNetworks.vue'
import Carrusel from '@/components/Carrusel.vue'

export default {
  name: 'HomeView',
  components: {
    HelloNetworks,
    Carrusel
  }
}
</script>
