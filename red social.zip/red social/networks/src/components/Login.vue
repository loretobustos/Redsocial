<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
  </div>
 
</template>

<script>
export default {
  name: "Login",
  props: {
    login: String,
  },
  data() {
  }

 
};
</script>

<style scoped>

</style>