<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <p>
      <a href="https://cli.vuejs.org" target="_blank" rel="noopener"> Registrate </a>
    </p>
  
    <h3>Conecta tus redes</h3>
    <ul>
      <li><a href="https://www.instagram.com/" target="_blank" rel="noopener">Instagram</a></li>
      <li><a href="https://es-la.facebook.com/" target="_blank" rel="noopener">Facebook</a></li>
      <li><a href="https://www.tiktok.com/es/" target="_blank" rel="noopener">TikTok</a></li>
      <li><a href="https://twitter.com/" target="_blank" rel="noopener">Twitter</a></li>
      <li><a href="https://www.youtube.com/" target="_blank" rel="noopener">Youtube</a></li>
    </ul>
   
  </div>
</template>

<script>
export default {
  name: 'HelloNetworks',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #580658;
}
</style>
