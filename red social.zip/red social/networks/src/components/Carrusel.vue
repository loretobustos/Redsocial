<template>
  <div>
    <h1>{{ carrusel }}</h1>
    <div class="body">
      <input type="radio" name="position" checked />
      <input type="radio" name="position" />
      <input type="radio" name="position" />
      <input type="radio" name="position" />
      <input type="radio" name="position" />
      <div id="carousel">
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
      </div>
    </div>

<div class="container">
  <div class="carousel">
    <div class="carousel__face"><span>This is something</span></div>
    <div class="carousel__face"><span>Very special</span></div>
    <div class="carousel__face"><span>Special is the key</span></div>
    <div class="carousel__face"><span>For you</span></div>
    <div class="carousel__face"><span>Just give it</span></div>
    <div class="carousel__face"><span>A try</span></div>
    <div class="carousel__face"><span>And see</span></div>
    <div class="carousel__face"><span>How IT Works</span></div>
    <div class="carousel__face"><span>Woow</span></div>
  </div>
</div>

  </div>
</template>

<script>
export default {
  name: "Carrusel",
  props: {
    carrusel: String,
  },
  data: function () {
    return {};
  },
  // computed: {},
  methods: {
    // -- Metodos
  },
  // components: {},
};
</script>

<style scoped>
.body {
  height: 600px;
  margin: 0;
  display: grid;
  grid-template-rows: 500px 100px;
  grid-template-columns: 1fr 30px 30px 30px 30px 30px 1fr;
  align-items: center;
  justify-items: center;
}

div#carousel {
  grid-row: 1 / 2;
  grid-column: 1 / 8;
  width: 100vw;
  height: 500px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  transform-style: preserve-3d;
  perspective: 600px;
  --items: 5;
  --middle: 3;
  --position: 1;
  pointer-events: none;
}

div.item {
  position: absolute;
  width: 300px;
  height: 400px;
  background-color: coral;
  --r: calc(var(--position) - var(--offset));
  --abs: max(calc(var(--r) * -1), var(--r));
  transition: all 0.25s linear;
  transform: rotateY(calc(-10deg * var(--r)))
    translateX(calc(-300px * var(--r)));
  z-index: calc((var(--position) - var(--abs)));
}

div.item:nth-of-type(1) {
  --offset: 1;
  background-color: #90f1ef;
}
div.item:nth-of-type(2) {
  --offset: 2;
  background-color: #ff70a6;
}
div.item:nth-of-type(3) {
  --offset: 3;
  background-color: #ff9770;
}
div.item:nth-of-type(4) {
  --offset: 4;
  background-color: #ffd670;
}
div.item:nth-of-type(5) {
  --offset: 5;
  background-color: #e9ff70;
}

input:nth-of-type(1) {
  grid-column: 2 / 3;
  grid-row: 2 / 3;
}
input:nth-of-type(1):checked ~ div#carousel {
  --position: 1;
}

input:nth-of-type(2) {
  grid-column: 3 / 4;
  grid-row: 2 / 3;
}
input:nth-of-type(2):checked ~ div#carousel {
  --position: 2;
}

input:nth-of-type(3) {
  grid-column: 4 /5;
  grid-row: 2 / 3;
}
input:nth-of-type(3):checked ~ div#carousel {
  --position: 3;
}

input:nth-of-type(4) {
  grid-column: 5 / 6;
  grid-row: 2 / 3;
}
input:nth-of-type(4):checked ~ div#carousel {
  --position: 4;
}

input:nth-of-type(5) {
  grid-column: 6 / 7;
  grid-row: 2 / 3;
}
input:nth-of-type(5):checked ~ div#carousel {
  --position: 5;
}
body {
  margin: 0;
  background: lightgray;
  text-align: center;
  font-family: sans-serif;
  color: #fefefe;
}
.container {
  position: relative;
  width: 320px;
  margin: 100px auto 0 auto;
  perspective: 1000px;
}

.carousel {
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d; 
  animation: rotate360 60s infinite forwards linear;
}
.carousel__face { 
  position: absolute;
  width: 300px;
  height: 187px;
  top: 20px;
  left: 10px;
  right: 10px;
  background-size: cover;
  box-shadow:inset 0 0 0 2000px rgba(228, 207, 248, 0.5);
  display: flex;
}

span {
  margin: auto;
  font-size: 2rem;
}


.carousel__face:nth-child(1) {
  background-image: url("https://as2.ftcdn.net/v2/jpg/03/03/59/55/1000_F_303595547_mTyJ2kkTka7GiEGykulzOGtoeATObdhD.jpg");
  transform: rotateY(  0deg) translateZ(430px); }
.carousel__face:nth-child(2) { 
  background-image: url("https://t4.ftcdn.net/jpg/05/10/89/51/240_F_510895186_pokTXMbWAhZUU4w7SpoezvqMvqBnADGq.jpg");
    transform: rotateY( 40deg) translateZ(430px); }
.carousel__face:nth-child(3) {
  background-image: url("https://t3.ftcdn.net/jpg/03/68/78/72/240_F_368787279_bYpjh1swdbmItHhbzt1DhJO38ZMzk8eB.jpg");
  transform: rotateY( 80deg) translateZ(430px); }
.carousel__face:nth-child(4) {
  background-image: url("https://t3.ftcdn.net/jpg/03/74/85/80/240_F_374858067_1VJQv1OWg2BO7vN8tcYnMYwa5R2p1HQt.jpg");
  transform: rotateY(120deg) translateZ(430px); }
.carousel__face:nth-child(5) { 
  background-image: url("https://t4.ftcdn.net/jpg/02/99/30/79/240_F_299307991_NZOD0UmCG9P7zts4c0M4CNA0ytXJXnql.jpg");
 transform: rotateY(160deg) translateZ(430px); }
.carousel__face:nth-child(6) { 
  background-image: url("https://t3.ftcdn.net/jpg/02/28/69/02/240_F_228690296_REqVrj3LV1Ltxh7Oeql4M5hvlIKN4JhM.jpg");
 transform: rotateY(200deg) translateZ(430px); }
.carousel__face:nth-child(7) { 
  background-image: url("https://t3.ftcdn.net/jpg/03/15/99/42/240_F_315994224_gvy8RwlBMsi47kxq2BYxY4OdFoIVfP7C.jpg");
 transform: rotateY(240deg) translateZ(430px); }
.carousel__face:nth-child(8) {
  background-image: url("https://t3.ftcdn.net/jpg/02/64/67/38/240_F_264673879_gTegjnVxnDUOKpVhWQh1QvkSxLK1H5cn.jpg");
  transform: rotateY(280deg) translateZ(430px); }
.carousel__face:nth-child(9) {
  background-image: url("https://t4.ftcdn.net/jpg/03/47/85/13/240_F_347851323_BTayha8PrsX20oOKwwLGHP5Zlc7rzOs1.jpg");
  transform: rotateY(320deg) translateZ(430px); }



@keyframes rotate360 {
  from {
    transform: rotateY(0deg);
  }
  to {
    transform: rotateY(-360deg);
  }
}
</style>